package com.northerncity.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.io.*;



@Service
public class EmailServiceImpl implements EmailService {
	
	@Autowired
	private JavaMailSender mailSender;
	
	@Value("${spring.mail.username}")
	private String sender;

	@Override
	public boolean sendMailWithAttachment(EmailDetail mailDetail) {
		// Creating a Mime Message
		MimeMessage mimeMessage = mailSender.createMimeMessage();
		MimeMessageHelper mimeMessageHelper;

		try {

			// Setting multipart as true for attachment to be send
			mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
			mimeMessageHelper.setFrom("zautingmai@gmail.com");
			mimeMessageHelper.setTo("northerncitycenter@gmail.com");
			mimeMessageHelper.setSubject(mailDetail.getSubject());
			mimeMessageHelper.setText(mailDetail.getMsgBody());

    // Adding the file attachment
	FileSystemResource file = new FileSystemResource(new File(mailDetail.getAttachment()));

			mimeMessageHelper.addAttachment(file.getFilename(), file);

			// Sending the email with attachment
			mailSender.send(mimeMessage);
			return true;
		}

		// Catch block to handle the MessagingException
		catch (MessagingException e) {

			// Display message when exception is occurred
			return false;
		}
	}

}
