package com.northerncity.springboot;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

@Controller
public class MailController {
	
	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private PDFService pdfservice;
	
	
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private JavaMailSender mailSender;
	
	
	@GetMapping("/order")
	public String orderPage(Model model) {
		Order order=orderRepo.getById((long)1);
		model.addAttribute("order",order);
		return "order";
	}
	
	
	@PostMapping(value = "/saveOrder")
	public String generateDocument(@ModelAttribute("order") Order myorder) {
		
		String finalHtml = null;
		
		
		String name=myorder.getName();
		String price=String.valueOf(myorder.getPrice());
		
		String customer_email=myorder.getCustomer_email();
		String customer_phone=myorder.getPhone();
		String customer_address=myorder.getAddress();
		
		
		
		finalHtml="<html><body><h3>Order Form</h3><br>"
				+ " Product Info: <br><hr>"
				+ " Product Name : "+ name+" <br> "
				+ "Price : "+price+"<br>"
				+ " Customer Info: <br> <hr> "
				+ " Customer Email: "+customer_email
				+ " Customer Phone: "+customer_phone
				+ " Customer Address: "+customer_address
				+"</body></html>";
		
		
		pdfservice.convertHTMLtoPDF(finalHtml);
		
		
		/* sending pdf file copy to customer email */
		
		Order updateOrder=orderRepo.getById((long)1);
		
		EmailDetail emailDetail=new EmailDetail();
		emailDetail.setRecipient(customer_email);
		emailDetail.setMsgBody("Customer Order Details and Receipt");
		emailDetail.setAttachment(updateOrder.getAttachment());
		emailDetail.setSubject("Northern City Online Shop");
		
		
		if(emailService.sendMailWithAttachment(emailDetail)) {
			return "success";
		}
		else {
			return "fail";
		}

		
		
	}

}
