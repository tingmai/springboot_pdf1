package com.northerncity.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailAttachmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailAttachmentApplication.class, args);
	}

}
