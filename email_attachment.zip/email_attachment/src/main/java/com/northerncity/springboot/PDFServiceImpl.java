package com.northerncity.springboot;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.html2pdf.resolver.font.DefaultFontProvider;
import com.itextpdf.io.source.ByteArrayOutputStream;
import com.itextpdf.kernel.pdf.PdfWriter;

@Service
public class PDFServiceImpl implements PDFService{

	@Override
	public void convertHTMLtoPDF(String htmlCodes) {
		// TODO Auto-generated method stub
		
ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		
		try {
			
			PdfWriter pdfwriter = new PdfWriter(byteArrayOutputStream);
			
			DefaultFontProvider defaultFont = new DefaultFontProvider(false, true, false);
			
			ConverterProperties converterProperties = new ConverterProperties();
			
			converterProperties.setFontProvider(defaultFont);
			
			HtmlConverter.convertToPdf(htmlCodes, pdfwriter, converterProperties);
			
			//create pdf file folder
			Random rand=new Random();
			int random_no=rand.nextInt(9999)+1000;
			String file_name="order"+random_no+".pdf";
			
			String pdfDir="./pdf_files/"+file_name;
			
	
			FileOutputStream fout = new FileOutputStream(pdfDir);
			
			byteArrayOutputStream.writeTo(fout);
			byteArrayOutputStream.close();
			
			byteArrayOutputStream.flush();
			fout.close();
			
			
			
		} catch(Exception ex) {
			
			ex.printStackTrace();
		}
		
		
		
	}

}
