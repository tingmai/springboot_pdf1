package com.northerncity.springboot;

public interface EmailService {
	
	boolean sendMailWithAttachment(EmailDetail mailDetail);

}
