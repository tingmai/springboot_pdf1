package com.northerncity.springboot;

public interface PDFService {
	
	public void convertHTMLtoPDF(String htmlCodes);

}
